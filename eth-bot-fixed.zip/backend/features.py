import pandas as pd
import ta


def add_indicators(df: pd.DataFrame) -> pd.DataFrame:
    df = df.copy()
    close = df["close"]

    df["ema_20"] = ta.trend.EMAIndicator(close, window=20).ema_indicator()
    df["ema_50"] = ta.trend.EMAIndicator(close, window=50).ema_indicator()
    df["ema_200"] = ta.trend.EMAIndicator(close, window=200).ema_indicator()
    df["rsi_14"] = ta.momentum.RSIIndicator(close, window=14).rsi()

    window = 20
    df["recent_high"] = df["high"].rolling(window).max()
    df["recent_low"] = df["low"].rolling(window).min()
    return df


def simple_signal(df: pd.DataFrame) -> dict:
    last = df.iloc[-1]

    price = last["close"]
    ema_200 = last["ema_200"]
    rsi = last["rsi_14"]
    support = last["recent_low"]
    resistance = last["recent_high"]

    if pd.isna(ema_200) or pd.isna(rsi) or pd.isna(support) or pd.isna(resistance):
        return {
            "direction": "neutral",
            "price": float(price),
            "ema_200": None,
            "rsi_14": None,
            "support": None,
            "resistance": None,
            "reason": "Not enough data for indicators yet.",
        }

    parts = []

    if price > ema_200:
        trend = "up"
        parts.append("Price above EMA 200 (uptrend bias).")
    else:
        trend = "down"
        parts.append("Price below EMA 200 (downtrend bias).")

    if rsi > 60:
        mom = "bullish"
        parts.append("RSI > 60 (bullish momentum).")
    elif rsi < 40:
        mom = "bearish"
        parts.append("RSI < 40 (bearish momentum).")
    else:
        mom = "neutral"
        parts.append("RSI between 40 and 60 (neutral momentum).")

    if trend == "up" and mom == "bullish":
        direction = "up"
    elif trend == "down" and mom == "bearish":
        direction = "down"
    else:
        direction = "neutral"

    return {
        "direction": direction,
        "price": float(price),
        "ema_200": float(ema_200),
        "rsi_14": float(rsi),
        "support": float(support),
        "resistance": float(resistance),
        "reason": " ".join(parts),
    }
