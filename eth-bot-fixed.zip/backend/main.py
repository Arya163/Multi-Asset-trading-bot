from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from .config import ALLOWED_TIMEFRAMES
from .data_loader import get_ohlcv
from .features import add_indicators, simple_signal

app = FastAPI(title="Local ETH AI Analyst")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.get("/api/chart")
def api_chart(timeframe: str = "15m"):
    if timeframe not in ALLOWED_TIMEFRAMES:
        raise HTTPException(status_code=400, detail="Invalid timeframe")

    df = get_ohlcv(timeframe)
    df = add_indicators(df)

    candles = []
    for _, row in df.iterrows():
        candles.append(
            {
                "time": int(row["timestamp"].timestamp()),
                "open": float(row["open"]),
                "high": float(row["high"]),
                "low": float(row["low"]),
                "close": float(row["close"]),
                "volume": float(row["volume"]),
            }
        )

    last = df.iloc[-1]
    sr = {
        "support": float(last["recent_low"]) if not pd.isna(last["recent_low"]) else None,
        "resistance": float(last["recent_high"]) if not pd.isna(last["recent_high"]) else None,
    }

    return {"timeframe": timeframe, "candles": candles, "support_resistance": sr}


@app.get("/api/predict")
def api_predict(timeframe: str = "15m"):
    if timeframe not in ALLOWED_TIMEFRAMES:
        raise HTTPException(status_code=400, detail="Invalid timeframe")

    df = get_ohlcv(timeframe)
    df = add_indicators(df)
    signal = simple_signal(df)
    return {"timeframe": timeframe, "signal": signal}
