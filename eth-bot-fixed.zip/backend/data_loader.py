import ccxt
import pandas as pd
from .config import SYMBOL, EXCHANGE_NAME, CANDLE_LIMIT

exchange_class = getattr(ccxt, EXCHANGE_NAME)
exchange = exchange_class({"enableRateLimit": True})


def get_ohlcv(timeframe: str) -> pd.DataFrame:
    raw = exchange.fetch_ohlcv(SYMBOL, timeframe=timeframe, limit=CANDLE_LIMIT)
    df = pd.DataFrame(
        raw, columns=["timestamp", "open", "high", "low", "close", "volume"]
    )
    df["timestamp"] = pd.to_datetime(df["timestamp"], unit="ms")
    return df
