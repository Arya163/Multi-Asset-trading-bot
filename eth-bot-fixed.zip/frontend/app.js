const API = "http://127.0.0.1:8000";

const tfSelect = document.getElementById("tf");
const sigEl = document.getElementById("sig");
const chartDiv = document.getElementById("chart");
const refreshBtn = document.getElementById("refreshBtn");
const analyzeBtn = document.getElementById("analyzeBtn");

let chart;
let candleSeries;
let supportLineSeries;
let resistanceLineSeries;

function initChart() {
  if (!chartDiv) {
    console.error("Chart container not found");
    return;
  }

  if (chart) {
    chart.remove();
  }

  chart = LightweightCharts.createChart(chartDiv, {
    width: chartDiv.clientWidth,
    height: 400,
    layout: {
      background: { color: "#020617" },
      textColor: "#e5e7eb",
    },
    grid: {
      vertLines: { visible: false },
      horzLines: { visible: false },
    },
    rightPriceScale: { borderVisible: true },
    timeScale: { borderVisible: true },
  });

  candleSeries = chart.addCandlestickSeries();
  supportLineSeries = chart.addLineSeries({ lineWidth: 1 });
  resistanceLineSeries = chart.addLineSeries({ lineWidth: 1 });
}

async function loadChart() {
  const tf = tfSelect.value;
  try {
    const res = await fetch(`${API}/api/chart?timeframe=${tf}`);
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    const data = await res.json();

    const candles = data.candles || [];
    console.log("Candles received:", candles.length);

    if (!chart) {
      initChart();
    }

    if (candles.length === 0) {
      sigEl.textContent = "No candles returned from backend.";
      candleSeries.setData([]);
      supportLineSeries.setData([]);
      resistanceLineSeries.setData([]);
      return;
    }

    candleSeries.setData(candles);

    const firstTime = candles[0].time;
    const lastTime = candles[candles.length - 1].time;

    const support = data.support_resistance.support;
    const resistance = data.support_resistance.resistance;

    if (support) {
      supportLineSeries.setData([
        { time: firstTime, value: support },
        { time: lastTime, value: support },
      ]);
    } else {
      supportLineSeries.setData([]);
    }

    if (resistance) {
      resistanceLineSeries.setData([
        { time: firstTime, value: resistance },
        { time: lastTime, value: resistance },
      ]);
    } else {
      resistanceLineSeries.setData([]);
    }

    sigEl.textContent = `Chart loaded for timeframe ${tf}. Candles: ${candles.length}`;
  } catch (err) {
    console.error("Error loading chart:", err);
    sigEl.textContent = "Error loading chart: " + err.message;
  }
}

async function analyzeMarket() {
  const tf = tfSelect.value;
  try {
    const res = await fetch(`${API}/api/predict?timeframe=${tf}`);
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    const data = await res.json();
    const signal = data.signal;

    let arrow = "↔️";
    if (signal.direction === "up") arrow = "📈";
    if (signal.direction === "down") arrow = "📉";

    const priceStr = signal.price ? signal.price.toFixed(2) : "N/A";
    const rsiStr =
      signal.rsi_14 !== null && signal.rsi_14 !== undefined
        ? signal.rsi_14.toFixed(1)
        : "N/A";
    const supStr =
      signal.support !== null && signal.support !== undefined
        ? signal.support.toFixed(2)
        : "N/A";
    const resStr =
      signal.resistance !== null && signal.resistance !== undefined
        ? signal.resistance.toFixed(2)
        : "N/A";

    sigEl.textContent =
      `${arrow} TF: ${tf} | Dir: ${signal.direction.toUpperCase()} | ` +
      `Price: ${priceStr} | RSI: ${rsiStr} | Support: ${supStr} | Resistance: ${resStr} | ` +
      `Reason: ${signal.reason}`;
  } catch (err) {
    console.error("Error analyzing market:", err);
    sigEl.textContent = "Error analyzing market: " + err.message;
  }
}

window.addEventListener("resize", () => {
  if (chart) {
    chart.applyOptions({ width: chartDiv.clientWidth });
  }
});

refreshBtn.addEventListener("click", loadChart);
analyzeBtn.addEventListener("click", analyzeMarket);

window.addEventListener("DOMContentLoaded", () => {
  console.log("DOM loaded, initializing chart");
  initChart();
  loadChart();
});
